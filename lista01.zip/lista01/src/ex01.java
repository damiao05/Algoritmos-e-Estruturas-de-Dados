public class ex01 {
    public static void main(String[] args) {

        System.out.print("Olá, Mundo!");
    }
}
