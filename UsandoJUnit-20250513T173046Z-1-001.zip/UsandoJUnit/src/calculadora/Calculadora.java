package calculadora;

public class Calculadora {

	public Double soma(double d, double e) {
		// TODO Auto-generated method stub
		return d + e;
	}

	public Double subtracao(double d, double e) {
		// TODO Auto-generated method stub
		return d - e;
	}

	public Double multipliacacao(double d, double e) {
		// TODO Auto-generated method stub
		return d * e;
	}

	public Double divisao(double d, double e) {
		// TODO Auto-generated method stub
		return d / e;
	}

	public Double potenciacao(double d, double e) {
		// TODO Auto-generated method stub
		return Math.pow(d, e);
	}

}
